CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',
  plan TEXT NOT NULL DEFAULT 'free',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transcripts (
  id SERIAL PRIMARY KEY,
  classroom_id TEXT,
  host_id INTEGER,
  raw_text TEXT,
  summary TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER,
  kind TEXT,
  request_text TEXT,
  response_text TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);


-- Track per-user AI usage and estimated cost (for cost control)
CREATE TABLE IF NOT EXISTS ai_usage (
  id SERIAL PRIMARY KEY,
  user_id INTEGER,
  month_key TEXT, -- e.g. '2025-02'
  estimated_cost_usd NUMERIC(10,4) DEFAULT 0,
  calls_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Track support tickets AI tries to resolve automatically
CREATE TABLE IF NOT EXISTS support_tickets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER,
  status TEXT DEFAULT 'open', -- open | ai_resolved | human_needed
  category TEXT,
  message TEXT,
  ai_response TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Track system events (for future AI monitoring of hardware/software/billing)
CREATE TABLE IF NOT EXISTS system_events (
  id SERIAL PRIMARY KEY,
  event_type TEXT,
  details TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
