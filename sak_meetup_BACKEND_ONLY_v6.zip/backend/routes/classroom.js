const express = require("express");
const router = express.Router();
const db = require("../simpleDb");

// In-memory room state for demo
const roomStates = new Map(); // roomId -> { muteAll, videoOn, chatEnabled, whiteboardEnabled }

function getDefaultState() {
  return {
    muteAll: false,
    videoOn: true,
    chatEnabled: true,
    whiteboardEnabled: true
  };
}

// Teacher updates controls (Educational plan only ideally)
// body: { roomId, muteAll?, videoOn?, chatEnabled?, whiteboardEnabled? }
router.post("/controls", async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    // Only educational plan (teachers / orgs) should control full room
    if (user.plan !== "educational") {
      return res.status(403).json({ error: "Only Educational plan can control room." });
    }

    const { roomId, muteAll, videoOn, chatEnabled, whiteboardEnabled } = req.body || {};
    if (!roomId) {
      return res.status(400).json({ error: "Missing roomId" });
    }

    const prev = roomStates.get(roomId) || getDefaultState();
    const next = Object.assign({}, prev, {
      muteAll: typeof muteAll === "boolean" ? muteAll : prev.muteAll,
      videoOn: typeof videoOn === "boolean" ? videoOn : prev.videoOn,
      chatEnabled: typeof chatEnabled === "boolean" ? chatEnabled : prev.chatEnabled,
      whiteboardEnabled:
        typeof whiteboardEnabled === "boolean" ? whiteboardEnabled : prev.whiteboardEnabled
    });

    roomStates.set(roomId, next);

    res.json({ ok: true, state: next });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Room control error" });
  }
});

// Any client can read current room controls to apply UI logic
// GET /api/classroom/controls?roomId=ROOM
router.get("/controls", async (req, res) => {
  try {
    const { roomId } = req.query;
    if (!roomId) {
      return res.status(400).json({ error: "Missing roomId" });
    }
    const state = roomStates.get(roomId) || getDefaultState();
    res.json({ ok: true, state });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Room state error" });
  }
});

// Breakout rooms
// For simplicity, we keep them in memory via simpleDb-like functions
const breakoutRooms = new Map(); // classId -> [ { id, name, studentIds } ]

// Teacher creates breakout rooms
// body: { classId, rooms: [ { name, studentIds[] } ] }
router.post("/breakouts", async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    if (user.plan !== "educational") {
      return res.status(403).json({ error: "Only Educational plan can manage breakouts." });
    }

    const { classId, rooms } = req.body || {};
    if (!classId || !Array.isArray(rooms)) {
      return res.status(400).json({ error: "classId and rooms are required" });
    }

    const list = rooms.map((r, idx) => ({
      id: classId + "_br_" + (idx + 1),
      name: r.name || "Group " + (idx + 1),
      studentIds: Array.isArray(r.studentIds) ? r.studentIds : []
    }));

    breakoutRooms.set(classId, list);
    res.json({ ok: true, breakouts: list });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Breakout create error" });
  }
});

// Get breakout rooms for a class
// GET /api/classroom/breakouts?classId=ID
router.get("/breakouts", async (req, res) => {
  try {
    const { classId } = req.query;
    if (!classId) {
      return res.status(400).json({ error: "Missing classId" });
    }
    const list = breakoutRooms.get(classId) || [];
    res.json({ ok: true, breakouts: list });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Breakout list error" });
  }
});

module.exports = router;
