const express = require("express");
const router = express.Router();
const { AccessToken } = require("livekit-server-sdk");

// POST /api/livekit/token
// body: { roomName, userName }
router.post("/token", async (req, res) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { roomName, userName } = req.body || {};
    const room = roomName || "demo";
    const identity = userName || user.id || "guest";

    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;
    const wsUrl = process.env.LIVEKIT_WS_URL;

    if (!apiKey || !apiSecret || !wsUrl) {
      return res.status(500).json({ error: "LiveKit not configured on server." });
    }

    const at = new AccessToken(apiKey, apiSecret, {
      identity,
    });
    at.addGrant({
      roomJoin: true,
      room,
    });

    const token = await at.toJwt();

    res.json({
      ok: true,
      token,
      wsUrl,
      room,
      identity
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "LiveKit token error" });
  }
});

module.exports = router;
