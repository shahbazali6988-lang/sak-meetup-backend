const express = require("express");
const router = express.Router();
const db = require("../simpleDb");
const { chooseModelForAction, callModel } = require("../aiManager");
const { getAllowedTier, logUsageAndUpdate } = require("../costControl");

// Student inbox: AI notifications, transcripts ready, homework ready, etc.
router.get("/inbox", async (req, res) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const messages = await db.listMessagesForUser(user.id);
    res.json({ ok: true, messages });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Inbox error" });
  }
});

// Student transcripts list
router.get("/transcripts", async (req, res) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const items = await db.listTranscriptsForUser(user.id);
    const locked = user.plan === "free";

    const mapped = items.map(v => ({
      videoId: v.id,
      classId: v.class_id,
      title: v.title,
      createdAt: v.created_at,
      source: v.transcript_source,
      locked,
      // Only send a small preview if paid
      transcriptPreview:
        locked || !v.transcript_text
          ? null
          : (v.transcript_text || "").slice(0, 160) + "..."
    }));

    res.json({ ok: true, transcripts: mapped });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Transcripts error" });
  }
});

// Student asks SK AI for homework help / "what is my homework?"
// body: { question: string, action?: string }
router.post("/ask-ai", async (req, res) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { question, action } = req.body || {};
    if (!question) {
      return res.status(400).json({ error: "Missing question" });
    }

    // Free users: only marketing / upgrade message
    if (user.plan === "free") {
      return res.json({
        ok: true,
        locked: true,
        reply:
          "Your homework help is ready. Upgrade to Student Pro to see full answers, explanations and transcripts."
      });
    }

    const aiAction = action || "homework_help";
    const payload = { question };

    const provisionalChoice = chooseModelForAction(aiAction, payload, 4);
    const budget = await getAllowedTier(
      user,
      aiAction,
      provisionalChoice.estimatedCostCents
    );
    const finalChoice = chooseModelForAction(
      aiAction,
      payload,
      budget.allowedTierMax
    );

    const modelReply = await callModel(finalChoice.model, payload);

    await logUsageAndUpdate(
      user.id,
      aiAction,
      finalChoice.tier,
      finalChoice.model,
      finalChoice.estimatedCostCents
    );

    // Teacher cannot see this; stored only as private AI help if you want later.
    res.json({
      ok: true,
      locked: false,
      reply: modelReply.reply,
      mode: budget.mode || "normal"
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Student AI error" });
  }
});

module.exports = router;
