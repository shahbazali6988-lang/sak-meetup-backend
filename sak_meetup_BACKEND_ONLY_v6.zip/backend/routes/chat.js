const express = require("express");
const router = express.Router();
const db = require("../simpleDb");

// Private 1-to-1 chat like WhatsApp.
// Teacher cannot read private messages; only participants see them.

// Send message
// body: { toUserId: string, text: string }
router.post("/send", async (req, res) => {
  try {
    const from = req.user;
    if (!from) return res.status(401).json({ error: "Unauthorized" });

    const { toUserId, text } = req.body || {};
    if (!toUserId || !text) {
      return res.status(400).json({ error: "Missing toUserId or text" });
    }

    const blocked = await db.isBlocked(from.id, toUserId);
    if (blocked) {
      return res.status(403).json({ error: "You cannot message this user." });
    }

    const msg = await db.insertMessage({
      to_user_id: toUserId,
      from_user_id: from.id,
      type: "dm",
      text,
      meta: {}
    });

    res.json({ ok: true, message: msg });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Chat send error" });
  }
});

// Inbox (DMs only)
router.get("/inbox", async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const messages = await db.listMessagesForUser(user.id);
    const dms = messages.filter(m => m.type === "dm");

    res.json({ ok: true, messages: dms });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Chat inbox error" });
  }
});

// Block private DM from a user
// body: { targetUserId: string }
router.post("/block", async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { targetUserId } = req.body || {};
    if (!targetUserId) {
      return res.status(400).json({ error: "Missing targetUserId" });
    }

    await db.blockUser(user.id, targetUserId);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Block error" });
  }
});

module.exports = router;
