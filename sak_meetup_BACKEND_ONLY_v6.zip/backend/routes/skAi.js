const express = require("express");
const router = express.Router();
const { chooseModelForAction, callModel } = require("../aiManager");
const { getAllowedTier, logUsageAndUpdate } = require("../costControl");

// Generic SK AI endpoint: classroom / student / teacher can call this.
// body: { action: string, payload: object }
router.post("/sk-ai", async (req, res) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { action, payload } = req.body || {};
    if (!action) {
      return res.status(400).json({ error: "Missing action" });
    }

    // Free plan rule: no real content, only marketing
    if (user.plan === "free") {
      return res.json({
        ok: true,
        locked: true,
        reply:
          "Your SK AI answer is ready. Upgrade your plan to Student Pro or Educational to unlock full help."
      });
    }

    // Student Pro + Educational: full AI help, but cost-controlled
    const provisionalChoice = chooseModelForAction(action, payload, 4);
    const budget = await getAllowedTier(
      user,
      action,
      provisionalChoice.estimatedCostCents
    );

    const finalChoice = chooseModelForAction(
      action,
      payload,
      budget.allowedTierMax
    );

    const modelReply = await callModel(finalChoice.model, payload);

    await logUsageAndUpdate(
      user.id,
      action,
      finalChoice.tier,
      finalChoice.model,
      finalChoice.estimatedCostCents
    );

    res.json({
      ok: true,
      locked: false,
      reply: modelReply.reply,
      mode: budget.mode || "normal"
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "SK AI error" });
  }
});

module.exports = router;
