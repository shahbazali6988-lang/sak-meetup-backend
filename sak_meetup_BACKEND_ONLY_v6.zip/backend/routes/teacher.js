const express = require("express");
const router = express.Router();
const db = require("../simpleDb");
const { processVideoForStudents } = require("../transcriptEngine");
const { chooseModelForAction, callModel } = require("../aiManager");
const { getAllowedTier, logUsageAndUpdate } = require("../costControl");

// Teacher posts a video link into class
// body: { classId: string, link: string, title?: string, studentIds?: string[] }
router.post("/video-link", async (req, res) => {
  try {
    const teacher = req.user;
    if (!teacher) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { classId, link, title, studentIds } = req.body || {};
    if (!classId || !link) {
      return res.status(400).json({ error: "classId and link are required" });
    }

    const video = await db.insertVideo({
      class_id: classId,
      link,
      title: title || "Class video",
      created_at: new Date().toISOString()
    });

    const students = Array.isArray(studentIds) ? studentIds : [];

    await processVideoForStudents({
      video,
      teacher,
      studentIds: students
    });

    res.json({
      ok: true,
      videoId: video.id,
      message: "Video processed and transcript + student notifications created."
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Teacher video error" });
  }
});

// Teacher private AI assistant
// body: { prompt: string, action?: string }
router.post("/ask-ai", async (req, res) => {
  try {
    const teacher = req.user;
    if (!teacher) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { prompt, action } = req.body || {};
    if (!prompt) {
      return res.status(400).json({ error: "Missing prompt" });
    }

    const aiAction = action || "teacher_assistant";
    const payload = { prompt };

    // Educational plan: full power; free teacher: marketing only
    if (teacher.plan === "free") {
      return res.json({
        ok: true,
        locked: true,
        reply:
          "Your SK AI teaching assistant answer is ready. Upgrade to Educational plan to unlock full tools."
      });
    }

    const provisionalChoice = chooseModelForAction(aiAction, payload, 4);
    const budget = await getAllowedTier(
      teacher,
      aiAction,
      provisionalChoice.estimatedCostCents
    );
    const finalChoice = chooseModelForAction(
      aiAction,
      payload,
      budget.allowedTierMax
    );
    const modelReply = await callModel(finalChoice.model, payload);

    await logUsageAndUpdate(
      teacher.id,
      aiAction,
      finalChoice.tier,
      finalChoice.model,
      finalChoice.estimatedCostCents
    );

    res.json({
      ok: true,
      locked: false,
      reply: modelReply.reply,
      mode: budget.mode || "normal"
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Teacher AI error" });
  }
});

module.exports = router;
