const express = require("express");
const router = express.Router();
const { canChoosePlan } = require("../planRules");
const db = require("../simpleDb");

// Change plan: free | student_pro | educational
router.post("/change-plan", async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { plan } = req.body || {};
    if (!plan) {
      return res.status(400).json({ error: "Missing plan" });
    }

    if (!canChoosePlan(user, plan)) {
      return res.status(403).json({
        error:
          "You are not allowed to use this plan with this account type (student/teacher/NGO/org rule)."
      });
    }

    // In this simple demo, we just change it in memory
    const updated = Object.assign({}, user, { plan });
    await db.upsertUser(updated);
    req.user = updated;

    res.json({ ok: true, plan });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Change plan error" });
  }
});

module.exports = router;
