const express = require("express");
const router = express.Router();
const { canChoosePlan } = require("../planRules");
const db = require("../simpleDb");

// Load Stripe secret key from environment
const stripeSecret = process.env.STRIPE_SECRET_KEY || "";
let stripe = null;
if (stripeSecret) {
  stripe = require("stripe")(stripeSecret);
}

// Map plan -> Stripe price ID (fill with real IDs from your Stripe dashboard)
const PRICE_IDS = {
  student_pro: process.env.STRIPE_PRICE_STUDENT_PRO || "price_student_pro_placeholder",
  educational: process.env.STRIPE_PRICE_EDUCATIONAL || "price_educational_placeholder"
};

// Helper to get base URLs for redirect
function getSuccessUrl() {
  return process.env.SUCCESS_URL || "http://localhost:8080/payment-success.html";
}
function getCancelUrl() {
  return process.env.CANCEL_URL || "http://localhost:8080/payment-cancel.html";
}

// Create a Stripe Checkout session for the selected plan
router.post("/checkout", async (req, res) => {
  try {
    if (!stripe) {
      return res.status(500).json({ error: "Stripe is not configured on the server." });
    }

    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const plan = (req.body && req.body.plan) || "student_pro";
    if (!PRICE_IDS[plan]) {
      return res.status(400).json({ error: "Unknown plan." });
    }

    // Check if this user is allowed to choose this plan (student_pro vs educational)
    if (!canChoosePlan(user, plan)) {
      return res.status(403).json({ error: "You are not allowed to buy this plan." });
    }

    const priceId = PRICE_IDS[plan];

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [
        {
          price: priceId,
          quantity: 1
        }
      ],
      success_url: getSuccessUrl() + "?session_id={CHECKOUT_SESSION_ID}",
      cancel_url: getCancelUrl(),
      customer_email: user.email || undefined,
      metadata: {
        sak_user_id: user.id,
        sak_plan: plan
      }
    });

    res.json({ ok: true, url: session.url });
  } catch (err) {
    console.error("Stripe checkout error", err);
    res.status(500).json({ error: "Stripe checkout error" });
  }
});

// Optional: webhook to confirm subscription and update the in memory user record.
// You must set STRIPE_WEBHOOK_SECRET in your environment and configure the endpoint in Stripe dashboard.
// Example endpoint path: /api/payment/webhook
router.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const sig = req.headers["stripe-signature"];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!stripe || !webhookSecret) {
    return res.status(500).send("Webhook not configured");
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error("Stripe webhook signature error", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const userId = session.metadata && session.metadata.sak_user_id;
      const plan = session.metadata && session.metadata.sak_plan;

      if (userId && plan) {
        // Update the in-memory user record so future requests see the new plan.
        await db.setUserPlan(userId, plan);
        await db.insertEvent({
          user_id: userId,
          type: "stripe_checkout_completed",
          plan,
          stripe_session_id: session.id,
          created_at: new Date().toISOString()
        });
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error("Stripe webhook handling error", err);
    res.status(500).send("Webhook handler error");
  }
});

module.exports = router;
