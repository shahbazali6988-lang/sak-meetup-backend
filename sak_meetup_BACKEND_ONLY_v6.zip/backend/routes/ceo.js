const express = require("express");
const router = express.Router();
const db = require("../simpleDb");

function currentMonthLabel() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
}

// GET /api/ceo/ai-metrics
router.get("/ai-metrics", async (req, res) => {
  try {
    const month = currentMonthLabel();
    const rows = await db.findAllUsageForMonth(month);

    const totalCost = rows.reduce(
      (sum, r) => sum + (r.total_cost_cents || 0),
      0
    );
    const userCount = rows.length || 1;
    const avgCost = totalCost / userCount;

    res.json({
      month,
      totalCostCents: totalCost,
      avgCostCentsPerUser: avgCost,
      userCount
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "CEO metrics error" });
  }
});

module.exports = router;
