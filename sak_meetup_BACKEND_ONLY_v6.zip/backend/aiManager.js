// AI Manager: decides which internal model to call for a given action.

const TIERS = {
  1: {
    name: "tier1_free",
    models: [
      { id: "local-small-llm", cost_per_1k_tokens_cents: 0 }
    ]
  },
  2: {
    name: "tier2_cheap",
    models: [
      { id: "cheap-transcript", cost_per_1k_tokens_cents: 10 } // $0.10
    ]
  },
  3: {
    name: "tier3_medium",
    models: [
      { id: "medium-llm", cost_per_1k_tokens_cents: 30 }
    ]
  },
  4: {
    name: "tier4_high",
    models: [
      { id: "high-llm", cost_per_1k_tokens_cents: 50 }
    ]
  }
};

const ACTION_PROFILES = {
  summarize_class:      { baseComplexity: 3, minTier: 1 },
  homework_help:        { baseComplexity: 4, minTier: 1 },
  quiz_from_lesson:     { baseComplexity: 5, minTier: 1 },
  translate_text:       { baseComplexity: 5, minTier: 2 },
  audio_transcript:     { baseComplexity: 6, minTier: 2 },
  hard_question:        { baseComplexity: 8, minTier: 3 },
  code_help:            { baseComplexity: 9, minTier: 4 },
  free_text:            { baseComplexity: 4, minTier: 1 },
  teacher_assistant:    { baseComplexity: 5, minTier: 1 },
  lesson_planner:       { baseComplexity: 6, minTier: 1 }
};

function estimateTokens(payload) {
  const text = JSON.stringify(payload || {});
  return Math.ceil(text.length / 4);
}

function estimateCostCents(tier, tokens) {
  const model = TIERS[tier].models[0];
  const per1k = model.cost_per_1k_tokens_cents;
  return Math.ceil((tokens / 1000) * per1k);
}

function chooseModelForAction(action, payload, allowedTierMax) {
  const profile = ACTION_PROFILES[action] || { baseComplexity: 3, minTier: 1 };
  const tokens = estimateTokens(payload);
  let tier = profile.minTier;

  if (tier > allowedTierMax) {
    tier = allowedTierMax;
  }

  const costCents = estimateCostCents(tier, tokens);

  return {
    tier,
    model: TIERS[tier].models[0].id,
    tokens,
    estimatedCostCents: costCents
  };
}

async function callModel(modelId, payload) {
  // Here you will plug your real AI providers.
  // For now this is a stub to let you test end-to-end.
  const prompt = payload && (payload.prompt || payload.question || payload.text || "");
  let prefix = "SK AI reply";

  if (modelId === "local-small-llm") {
    prefix = "SK AI Tier 1";
  } else if (modelId === "cheap-transcript") {
    prefix = "SK AI Tier 2";
  } else if (modelId === "medium-llm") {
    prefix = "SK AI Tier 3";
  } else if (modelId === "high-llm") {
    prefix = "SK AI Tier 4";
  }

  return {
    reply: prefix + " — processed: " + (prompt || "[no prompt]")
  };
}

module.exports = {
  chooseModelForAction,
  callModel
};
