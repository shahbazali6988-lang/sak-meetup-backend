// Plan & role rules for SAK Meetup

function canChoosePlan(user, desiredPlan) {
  if (desiredPlan === "student_pro") {
    // Student Pro only for individual students (no org_type)
    return user.role === "student" && !user.org_type;
  }

  if (desiredPlan === "educational") {
    // Educational only for teacher + NGOs + schools/colleges/universities
    const isTeacher = user.role === "teacher";
    const isOrg =
      user.org_type === "school" ||
      user.org_type === "college" ||
      user.org_type === "university" ||
      user.org_type === "ngo";
    return (isTeacher || isOrg) && user.verified;
  }

  if (desiredPlan === "free") return true;

  return false;
}

module.exports = {
  canChoosePlan
};
