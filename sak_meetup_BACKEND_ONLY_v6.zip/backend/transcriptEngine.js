// Transcript engine: tries "free" first, then "cheap paid" only if needed.
// This is a stub that simulates transcript creation.

const { logUsageAndUpdate } = require("./costControl");
const { chooseModelForAction, callModel } = require("./aiManager");
const db = require("./simpleDb");

async function generateTranscriptForVideo(video, teacher) {
  // Try free model first (Tier 1)
  const payload = { text: "Transcript for: " + video.link };
  const choiceFree = chooseModelForAction("audio_transcript", payload, 1);

  // Simulate "free succeeded"
  let transcriptText = "Auto transcript (free model) for video: " + video.link;
  let source = "free";

  // If in future you want to simulate failure and fallback to paid:
  // e.g. if video.link length is odd, fallback:
  if (video.link && video.link.length % 13 === 0) {
    // fallback to cheap paid (Tier 2)
    const choicePaid = chooseModelForAction("audio_transcript", payload, 2);
    const reply = await callModel(choicePaid.model, payload);
    transcriptText = "Auto transcript (paid model) for video: " + video.link;
    source = "paid_cheap";

    await logUsageAndUpdate(
      teacher.id,
      "audio_transcript",
      choicePaid.tier,
      choicePaid.model,
      choicePaid.estimatedCostCents
    );
  } else {
    // free path - cost is zero
  }

  const updated = await db.updateVideo(video.id, {
    transcript_text: transcriptText,
    transcript_source: source
  });

  return updated;
}

// After transcript is ready, create student notifications
async function processVideoForStudents({ video, teacher, studentIds }) {
  const v = await generateTranscriptForVideo(video, teacher);

  if (Array.isArray(studentIds)) {
    for (const sid of studentIds) {
      await db.insertMessage({
        to_user_id: sid,
        from_user_id: "sk_ai",
        type: "transcript_ready",
        text:
          "Your class video transcript is ready. " +
          "If you are on free plan, upgrade to open and download.",
        meta: {
          videoId: v.id
        }
      });
    }
  }

  // Teacher also gets a message that transcript is ready
  await db.insertMessage({
    to_user_id: teacher.id,
    from_user_id: "sk_ai",
    type: "teacher_transcript_ready",
    text: "Transcript is ready for your video: " + (v.title || v.link),
    meta: {
      videoId: v.id
    }
  });

  return v;
}

module.exports = {
  processVideoForStudents
};
