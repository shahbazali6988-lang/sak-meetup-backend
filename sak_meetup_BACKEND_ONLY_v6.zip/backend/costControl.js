// Cost control: keep per-user AI spend under limits.

const db = require("./simpleDb");

const MAX_COST_CENTS_PER_MONTH_PRO = 200; // $2.00
const MAX_COST_CENTS_PER_MONTH_FREE = 50; // $0.50

function currentMonthLabel() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
}

async function getUserMonthlyUsage(userId, month) {
  let row = await db.findUsage(userId, month);
  if (!row) {
    row = {
      user_id: userId,
      month,
      total_cost_cents: 0,
      total_requests: 0
    };
  }
  return row;
}

async function saveUserMonthlyUsage(row) {
  await db.saveUsage(row);
}

async function getAllowedTier(user, requestedAction, estimatedCostCents) {
  const month = currentMonthLabel();
  const usage = await getUserMonthlyUsage(user.id, month);
  const already = usage.total_cost_cents || 0;
  const projected = already + estimatedCostCents;

  const limit =
    user.plan === "free"
      ? MAX_COST_CENTS_PER_MONTH_FREE
      : MAX_COST_CENTS_PER_MONTH_PRO;

  if (already >= limit) {
    return { allowedTierMax: 1, mode: "fallback" };
  }

  if (projected > limit) {
    return { allowedTierMax: 1, mode: "downgrade" };
  }

  return { allowedTierMax: 4, mode: "normal" };
}

async function logUsageAndUpdate(userId, action, tier, model, costCents) {
  const month = currentMonthLabel();
  const usage = await getUserMonthlyUsage(userId, month);
  usage.total_cost_cents = (usage.total_cost_cents || 0) + costCents;
  usage.total_requests = (usage.total_requests || 0) + 1;
  await saveUserMonthlyUsage(usage);

  await db.insertEvent({
    user_id: userId,
    action,
    tier,
    model,
    actual_cost_cents: costCents,
    created_at: new Date().toISOString()
  });
}

module.exports = {
  getAllowedTier,
  logUsageAndUpdate
};
