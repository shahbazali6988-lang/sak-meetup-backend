// Simple in-memory "database" for demo and local testing.
// In production replace this with a real database.

const usage = new Map(); // key: userId::month -> { user_id, month, total_cost_cents }
const events = []; // audit log
const users = new Map(); // userId -> { id, plan, role, org_type, verified, email, created_at, updated_at }
const videos = new Map(); // videoId -> { id, owner_id, title, link, classId, transcripts: [], created_at }
const messages = []; // { id, user_id, from_user_id, to_user_id, type, text, meta, created_at }
const blocks = new Set(); // "userId::targetId"

let videoCounter = 1;
let messageCounter = 1;

function usageKey(userId, month) {
  return userId + "::" + month;
}

// ---------- Usage and cost tracking ----------

async function findUsage(userId, month) {
  const key = usageKey(userId, month);
  return usage.get(key) || null;
}

async function saveUsage(row) {
  if (!row || !row.user_id || !row.month) return;
  const key = usageKey(row.user_id, row.month);
  usage.set(key, Object.assign({}, row));
  return row;
}

async function findAllUsageForMonth(month) {
  const rows = [];
  for (const row of usage.values()) {
    if (row.month === month) rows.push(row);
  }
  return rows;
}

async function insertEvent(ev) {
  const row = Object.assign({}, ev);
  if (!row.created_at) {
    row.created_at = new Date().toISOString();
  }
  events.push(row);
  return row;
}

// ---------- Users ----------

async function upsertUser(user) {
  if (!user || !user.id) return null;
  const existing = users.get(user.id) || {};
  const now = new Date().toISOString();
  const merged = Object.assign(
    {
      id: user.id,
      plan: user.plan || existing.plan || "free",
      role: user.role || existing.role || "student",
      org_type: user.org_type || existing.org_type || null,
      verified: typeof user.verified === "boolean" ? user.verified : (existing.verified ?? true),
      email: user.email || existing.email || null,
      created_at: existing.created_at || now
    },
    existing,
    user,
    { updated_at: now }
  );
  users.set(merged.id, merged);
  return merged;
}

async function setUserPlan(userId, plan) {
  if (!userId) return null;
  const existing = users.get(userId) || { id: userId };
  existing.plan = plan;
  const now = new Date().toISOString();
  if (!existing.created_at) existing.created_at = now;
  existing.updated_at = now;
  users.set(userId, existing);
  return existing;
}

// ---------- Videos and transcripts ----------

async function insertVideo(video) {
  const id = String(videoCounter++);
  const row = Object.assign(
    {
      id,
      owner_id: video.owner_id || (video.teacher_id || null),
      transcripts: [],
      created_at: new Date().toISOString()
    },
    video
  );
  videos.set(id, row);
  return row;
}

async function updateVideo(videoId, patch) {
  const existing = videos.get(videoId);
  if (!existing) return null;
  const updated = Object.assign({}, existing, patch);
  videos.set(videoId, updated);
  return updated;
}

// Helper to add transcript to a video
async function insertTranscript(videoId, transcript) {
  const v = videos.get(videoId);
  if (!v) return null;
  if (!Array.isArray(v.transcripts)) v.transcripts = [];
  const row = Object.assign(
    {
      id: v.transcripts.length + 1,
      created_at: new Date().toISOString()
    },
    transcript
  );
  v.transcripts.push(row);
  videos.set(videoId, v);
  return row;
}

async function listVideosForUser(userId) {
  const list = [];
  for (const v of videos.values()) {
    if (v.owner_id === userId || v.teacher_id === userId) {
      list.push(v);
    }
  }
  return list;
}

async function listTranscriptsForUser(userId) {
  const out = [];
  for (const v of videos.values()) {
    if (!Array.isArray(v.transcripts)) continue;
    for (const t of v.transcripts) {
      if (!t.user_id || t.user_id === userId) {
        out.push(Object.assign({ videoId: v.id }, t));
      }
    }
  }
  return out;
}

// ---------- Messages and blocking ----------

async function insertMessage(msg) {
  const id = String(messageCounter++);
  const row = Object.assign(
    {
      id,
      created_at: new Date().toISOString()
    },
    msg
  );
  messages.push(row);
  return row;
}

async function listMessagesForUser(userId) {
  return messages.filter((m) => m.user_id === userId || m.to_user_id === userId);
}

async function blockUser(userId, targetId) {
  if (!userId || !targetId) return;
  blocks.add(userId + "::" + targetId);
}

async function isBlocked(userId, targetId) {
  if (!userId || !targetId) return false;
  return blocks.has(userId + "::" + targetId) || blocks.has(targetId + "::" + userId);
}

module.exports = {
  findUsage,
  saveUsage,
  insertEvent,
  findAllUsageForMonth,
  upsertUser,
  setUserPlan,
  insertVideo,
  updateVideo,
  insertTranscript,
  listVideosForUser,
  listTranscriptsForUser,
  insertMessage,
  listMessagesForUser,
  blockUser,
  isBlocked
};
