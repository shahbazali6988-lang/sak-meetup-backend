// Simple auth middleware for demo purposes.
// In production replace with real authentication (JWT / sessions).

const db = require("./simpleDb");

// Reads headers:
// x-user-id, x-user-plan, x-user-role, x-user-org-type, x-user-verified, x-user-email
function authMiddleware(req, res, next) {
  const userId = req.header("x-user-id") || "demo-student";
  const plan = req.header("x-user-plan") || "free"; // free | student_pro | educational
  const role = req.header("x-user-role") || "student"; // student | teacher | ngo | org
  const orgType = req.header("x-user-org-type") || null; // school | college | university | ngo | null
  const verified = (req.header("x-user-verified") || "true") === "true";
  const email = req.header("x-user-email") || null;

  const user = {
    id: userId,
    plan,
    role,
    org_type: orgType,
    verified,
    email
  };

  // Store or update in in-memory DB so other modules (payment, CEO, etc.) see a consistent view.
  db.upsertUser(user).then((saved) => {
    req.user = saved || user;
    next();
  }).catch((err) => {
    console.error("auth upsert error", err);
    req.user = user;
    next();
  });
}

// CEO middleware: only requests with x-ceo-secret: sk-ceo
function ceoMiddleware(req, res, next) {
  const secret = req.header("x-ceo-secret");
  if (secret !== "sk-ceo") {
    return res.status(403).json({ error: "Forbidden" });
  }
  req.ceo = true;
  next();
}

module.exports = {
  authMiddleware,
  ceoMiddleware
};
