const express = require("express");
const cors = require("cors");
const http = require("http");
const { WebSocketServer } = require("ws");
const { authMiddleware, ceoMiddleware } = require("./auth");

const skAiRouter = require("./routes/skAi");
const ceoRouter = require("./routes/ceo");
const teacherRouter = require("./routes/teacher");
const studentRouter = require("./routes/student");
const chatRouter = require("./routes/chat");
const accountRouter = require("./routes/account");
const paymentRouter = require("./routes/payment");
const classroomRouter = require("./routes/classroom");
const livekitRouter = require("./routes/livekit");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// Simple auth (header-based)
app.use(authMiddleware);

// Public / user routes
app.use("/api", skAiRouter);
app.use("/api/teacher", teacherRouter);
app.use("/api/student", studentRouter);
app.use("/api/chat", chatRouter);
app.use("/api/account", accountRouter);
app.use("/api/payment", paymentRouter);
app.use("/api/classroom", classroomRouter);
app.use("/api/livekit", livekitRouter);

// CEO metrics routes (protected)
app.use("/api/ceo", ceoMiddleware, ceoRouter);

app.get("/", (req, res) => {
  res.json({ ok: true, message: "SAK Meetup SK AI backend running." });
});

// Create HTTP server and attach WebSocket signaling server
const server = http.createServer(app);

// In-memory room -> set of clients
const rooms = new Map();

const wss = new WebSocketServer({ server, path: "/ws" });

function broadcastToRoom(roomId, data, exceptSocket) {
  const set = rooms.get(roomId);
  if (!set) return;
  const msg = JSON.stringify(data);
  for (const client of set) {
    if (client === exceptSocket) continue;
    if (client.readyState === client.OPEN) {
      client.send(msg);
    }
  }
}

wss.on("connection", (socket) => {
  socket.roomId = null;
  socket.userId = null;

  socket.on("message", (raw) => {
    let msg = null;
    try {
      msg = JSON.parse(raw.toString());
    } catch (e) {
      return;
    }

    if (msg.type === "join") {
      const { roomId, userId } = msg;
      socket.roomId = roomId;
      socket.userId = userId;

      if (!rooms.has(roomId)) {
        rooms.set(roomId, new Set());
      }
      const set = rooms.get(roomId);
      set.add(socket);

      // Send current peers to the new client
      const peers = Array.from(set)
        .filter((c) => c !== socket && !!c.userId)
        .map((c) => c.userId);

      socket.send(
        JSON.stringify({
          type: "peers",
          peers
        })
      );

      // Notify others that this peer joined
      broadcastToRoom(
        roomId,
        { type: "peer-joined", userId },
        socket
      );
      return;
    }

    // Forward signaling messages
    if (msg.type === "offer" || msg.type === "answer" || msg.type === "candidate") {
      const { to } = msg;
      const roomId = socket.roomId;
      const set = rooms.get(roomId);
      if (!set) return;
      for (const client of set) {
        if (client.userId === to && client.readyState === client.OPEN) {
          client.send(
            JSON.stringify({
              type: msg.type,
              from: socket.userId,
              offer: msg.offer,
              answer: msg.answer,
              candidate: msg.candidate
            })
          );
        }
      }
      return;
    }
  });

  socket.on("close", () => {
    const { roomId, userId } = socket;
    if (roomId && rooms.has(roomId)) {
      const set = rooms.get(roomId);
      set.delete(socket);
      if (set.size === 0) {
        rooms.delete(roomId);
      } else {
        broadcastToRoom(roomId, { type: "peer-left", userId }, socket);
      }
    }
  });
});

server.listen(PORT, () => {
  console.log("SAK Meetup backend (HTTP + WebSocket) listening on port " + PORT);
});
