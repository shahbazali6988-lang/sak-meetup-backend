# SAK Meetup — SK AI Backend

This project is a Node.js backend that matches your design:

- SK AI cost control under **$2 per user**
- Plans: **free**, **student_pro**, **educational**
- Roles: **student**, **teacher**, **ngo**, **org (school/college/university)**
- Educational plan for **teachers / NGOs / schools / colleges / universities only**
- Student Pro plan for **students only**
- **Free users** get only upgrade notifications (no real AI content)
- **Student Pro & Educational** get full AI help
- SK AI:
  - Generates transcripts (free models first, then cheap paid fallback)
  - Sends DM that transcript is ready
  - Helps students with homework (private, teacher cannot see)
  - Helps teachers with lesson planning, quizzes, polls, etc.
- 1-to-1 chat private like WhatsApp:
  - Teacher cannot read private DMs
  - Users can block DMs from others

## Files

- `server.js` — main Express server
- `auth.js` — simple header-based auth + CEO protection
- `aiManager.js` — AI tier/model chooser (stubbed)
- `costControl.js` — per-user cost limit
- `simpleDb.js` — in-memory database (replace with real DB later)
- `transcriptEngine.js` — auto transcript logic + notifications
- `planRules.js` — enforce who can use which plan
- `routes/skAi.js` — generic SK AI endpoint
- `routes/teacher.js` — teacher tools (video link, private AI)
- `routes/student.js` — student inbox, transcripts, homework AI
- `routes/chat.js` — private 1:1 chat + block
- `routes/account.js` — change plan with validation
- `routes/ceo.js` — CEO-only AI cost metrics

## How to run

1. Install Node.js (version 18+ recommended).

2. In this folder run:

   ```bash
   npm install
   npm start
   ```

   Server listens on **http://localhost:4000**

3. Example: call student homework AI (Student Pro)

   ```bash
   curl -X POST http://localhost:4000/api/student/ask-ai \
     -H "Content-Type: application/json" \
     -H "x-user-id: stu_1" \
     -H "x-user-plan: student_pro" \
     -H "x-user-role: student" \
     -d '{ "question": "What is my homework for chapter 4?" }'
   ```

4. Example: free student (only upgrade message)

   ```bash
   curl -X POST http://localhost:4000/api/student/ask-ai \
     -H "Content-Type: application/json" \
     -H "x-user-id: stu_2" \
     -H "x-user-plan: free" \
     -H "x-user-role: student" \
     -d '{ "question": "Explain this homework" }'
   ```

5. Example: teacher posts video link (Educational plan)

   ```bash
   curl -X POST http://localhost:4000/api/teacher/video-link \
     -H "Content-Type: application/json" \
     -H "x-user-id: teacher_1" \
     -H "x-user-plan: educational" \
     -H "x-user-role: teacher" \
     -d '{ "classId": "CLASS123", "link": "https://video.example.com/lesson1", "studentIds": ["stu_1","stu_2"] }'
   ```

   SK AI will:
   - create a video record
   - generate a fake transcript
   - send DM to each student: "Transcript ready, upgrade if free"

6. Example: CEO metrics

   ```bash
   curl http://localhost:4000/api/ceo/ai-metrics \
     -H "x-user-id: ceo_1" \
     -H "x-ceo-secret: sk-ceo"
   ```

## Next steps

- Replace `simpleDb.js` with a real database (Postgres, MySQL, Mongo, etc.).
- Replace `aiManager.callModel` with real AI providers (local models, cloud APIs).
- Integrate this backend with your SAK Meetup front-end (classroom, dashboards).


## Quick Docker Deploy

From the project root (where docker-compose.yml is):

```bash
docker-compose up --build -d
```

- Backend will be on http://your-server-ip:4000
- Frontend will be on http://your-server-ip:8080
