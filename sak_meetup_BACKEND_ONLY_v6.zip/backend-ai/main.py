
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta

app = FastAPI(title="SAK AI Backend", version="0.5.0")

# ---------- MODELS ----------

class AIQuestion(BaseModel):
    user_id: Optional[str] = None
    role: Optional[str] = "student"   # student | host | ceo
    plan: Optional[str] = "free"      # free | pro | educational | ceo
    question: str
    context: Optional[str] = None

class TranscriptRequest(BaseModel):
    classroom_id: Optional[str] = None
    role: Optional[str] = "host"
    plan: Optional[str] = "educational"
    transcript_text: str

class HomeworkRequest(BaseModel):
    classroom_id: Optional[str] = None
    text: str

class SupportRequest(BaseModel):
    user_id: Optional[str] = None
    message: str
    language: Optional[str] = "en"

class MarketingRequest(BaseModel):
    user_id: Optional[str] = None
    plan: Optional[str] = "free"
    behavior_hint: Optional[str] = None  # e.g. "active_free_user", "trial_ending"

# ---------- SIMPLE IN-MEMORY COST + RETENTION (PLACEHOLDER) ----------

ESTIMATED_COST_PER_CALL_USD = 0.01  # pretend each AI call costs ~$0.01
MONTHLY_COST_LIMIT_USD = 2.0        # internal target per user (NOT shown to users)
USAGE_NOTIFY_THRESHOLD = 0.8        # when reaching 80% of limit, notify (for Pro/CEO only)
DATA_RETENTION_DAYS = 60            # target to delete old AI logs after 45–60 days

# Very small in-memory store: user_id -> (estimated_cost, last_used_at)
estimated_cost_store = {}

def get_month_key() -> str:
    now = datetime.utcnow()
    return f"{now.year}-{now.month:02d}"

def has_sk_ai_access(plan: str) -> bool:
    return plan in ("pro", "educational", "ceo")

def get_estimated_cost(user_id: Optional[str]) -> float:
    if not user_id:
        return 0.0
    info = estimated_cost_store.get(user_id)
    if not info:
        return 0.0
    return info[0]

def add_cost(user_id: Optional[str], amount: float) -> None:
    if not user_id:
        return
    cost, _ = estimated_cost_store.get(user_id, (0.0, datetime.utcnow()))
    estimated_cost_store[user_id] = (cost + amount, datetime.utcnow())

def simple_ai_answer(prompt: str) -> str:
    # Placeholder to keep things running
    return (
        "SK-AI (demo): I received your request but this environment is not "
        "connected to a real AI model yet. On your server, connect this "
        "function to OpenAI / Llama and use the ai_usage table to track real cost."
    )

def get_retention_policy():
    return {
        "retention_days": DATA_RETENTION_DAYS,
        "note": "AI-related logs (transcripts, support, usage) should be deleted "
                "after ~45–60 days via a scheduled cleanup job in the real backend."
    }

# ---------- ENDPOINTS ----------

@app.get("/")
def root():
    return {"ok": True, "service": "sak-backend-ai", "version": "0.5.0"}

@app.get("/ai/usage")
def ai_usage(user_id: Optional[str] = None):
    return {
        "ok": True,
        "user_id": user_id,
        "estimated_cost_usd": get_estimated_cost(user_id),
        "limit_usd": MONTHLY_COST_LIMIT_USD,
        "notify_threshold": USAGE_NOTIFY_THRESHOLD,
        "retention_policy": get_retention_policy(),
    }

@app.post("/ai/question")
def ai_question(payload: AIQuestion):
    current_cost = get_estimated_cost(payload.user_id)
    nearing_limit = current_cost >= (MONTHLY_COST_LIMIT_USD * USAGE_NOTIFY_THRESHOLD)
    over_limit = current_cost >= MONTHLY_COST_LIMIT_USD

    # ---------- FREE PLAN: NO AI ANSWER ----------
    if payload.plan not in ("pro", "educational", "ceo"):
        # Free users do NOT get AI answers. Only a clear upgrade prompt.
        return {
            "ok": False,
            "answer": None,
            "mode": "free_blocked",
            "nearing_limit": False,
            "limit_reached": False,
            "upgrade_suggestion": (
                "SK-AI full answers, homework help and transcripts are not available on the free plan. "
                "Please upgrade to Student Pro or Educational plan to unlock SK-AI."
            )
        }

    # ---------- EDUCATIONAL PLAN: VERY GENEROUS / UNLIMITED STYLE ----------
    if payload.plan == "educational":
        prompt = f"[EDUCATIONAL USER]\nROLE={payload.role}\nQUESTION={payload.question}\nCONTEXT={payload.context or ''}"
        answer = simple_ai_answer(prompt)
        add_cost(payload.user_id, ESTIMATED_COST_PER_CALL_USD)
        return {
            "ok": True,
            "answer": answer,
            "mode": "educational_unlimited",
            "nearing_limit": False,
            "limit_reached": False,
            "note": (
                "Educational SK-AI users are intended to have very generous / unlimited-style access. "
                "On the real system, use free resources and efficient models first to keep cost low."
            )
        }

    # ---------- PRO / CEO PLANS: LIMITED WITH FREE-RESOURCES FALLBACK ----------
    if over_limit:
        # Over soft limit: still reply, but should only use free resources in a real system.
        answer = (
            "SK-AI: You have reached your monthly help usage for this plan. "
            "I will still try to assist you using free resources and cached information. "
            "Response quality may be lighter. You can contact support if you need extra limit."
        )
        return {
            "ok": True,
            "answer": answer,
            "mode": "free_resources_only",
            "nearing_limit": True,
            "limit_reached": True,
            "upgrade_suggestion": (
                "You reached your monthly SK-AI usage for this plan. You can wait for next month "
                "or contact support for a higher-limit bundle."
            )
        }

    # Normal paid call (under limit)
    prompt = f"ROLE={payload.role}\nQUESTION={payload.question}\nCONTEXT={payload.context or ''}"
    answer = simple_ai_answer(prompt)
    add_cost(payload.user_id, ESTIMATED_COST_PER_CALL_USD)

    return {
        "ok": True,
        "answer": answer,
        "mode": "paid_full",
        "nearing_limit": nearing_limit,
        "limit_reached": False,
        "upgrade_suggestion": (
            "If you need more usage each month, you can contact support "
            "for an Educational-style bundle with higher limits."
        ) if nearing_limit else None
    }

@app.post("/ai/transcript")
def ai_transcript(payload: TranscriptRequest):
    # Educational plan: effectively unlimited transcripts (from AI side).
    if payload.plan == "educational":
        summary = simple_ai_answer(
            f"[EDUCATIONAL USER TRANSCRIPT]\nSummarize transcript: {payload.transcript_text[:2000]}"
        )
        return {
            "ok": True,
            "summary": summary,
            "download_ready": True,
            "mode": "educational_unlimited",
            "retention_policy": get_retention_policy()
        }

    # Other plans: require paid access (Pro / CEO)
    if not has_sk_ai_access(payload.plan or "free"):
        return {
            "ok": False,
            "needs_upgrade": True,
            "message": "Transcript download is only for paid SK-AI users."
        }

    summary = simple_ai_answer(f"Summarize transcript: {payload.transcript_text[:1500]}")
    return {
        "ok": True,
        "summary": summary,
        "download_ready": True,
        "mode": "paid_transcript",
        "retention_policy": get_retention_policy()
    }

@app.post("/ai/homework")
def ai_homework(payload: HomeworkRequest):
    explanation = simple_ai_answer(f"Explain homework, simple steps: {payload.text[:1500]}")
    return {"ok": True, "homework_explained": explanation}

@app.post("/ai/support")
def ai_support(payload: SupportRequest):
    reply = simple_ai_answer(
        f"Support question from user {payload.user_id}: {payload.message}. "
        "In the real system, SK-AI should first try to fix common issues automatically "
        "(camera, mic, billing questions, password reset) before creating a human ticket."
    )
    return {
        "ok": True,
        "reply": reply,
        "retention_policy": get_retention_policy()
    }

@app.post("/ai/marketing")
def ai_marketing(payload: MarketingRequest):
    # Simple upsell helper: AI suggests upgrade messaging without revealing internal limits.
    if payload.plan == "educational":
        msg = (
            "Thank you for choosing the Educational SK-AI plan. You get very generous help, "
            "including transcripts and AI support designed for heavy classroom use."
        )
    elif payload.plan == "pro":
        msg = (
            "You are on the Student Pro plan. If you are using SK-AI heavily for many classes, "
            "you can talk to support about an Educational-style bundle with higher flexibility."
        )
    elif payload.plan == "ceo":
        msg = (
            "You are on a management / CEO plan. SK-AI can help you monitor usage and performance. "
            "Contact support to design a custom bundle for your institution."
        )
    else:
        msg = (
            "SK-AI answers, transcripts and homework help are reserved for paid plans. "
            "Upgrade to Student Pro or Educational plan to unlock SK-AI support."
        )
    return {"ok": True, "message": msg}
