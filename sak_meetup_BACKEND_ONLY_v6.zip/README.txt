Sak Meetup Full Project
=======================

This zip contains:

- backend/  -> SK AI backend (Node.js, Express)
- frontend/ -> Your SAK Meetup HTML/CSS/JS files + sak_api.js helper

How to use backend:
- See backend/README.md

How to use frontend:
- Open frontend/index.html in a browser for the landing page.
- The classroom, login, whiteboard, etc. are in the same folder.
- sak_api.js is a helper file to call the backend from your JS.

Next step:
- Inside your JS files (classroom.js, student_dashboard.js, teacher_dashboard.js),
  you can call sakApi("/api/...") to connect buttons to the backend routes.

This project is ready for you to customize and deploy.


Deployment (simple VPS with Docker)
-----------------------------------

1. Copy this entire folder to your server (via SFTP, git, etc.).

2. On the server, install Docker and Docker Compose.

3. In this folder run:

   docker-compose up --build -d

4. Access:
   - Frontend:  http://YOUR_SERVER_IP:8080
   - Backend:   http://YOUR_SERVER_IP:4000

Performance tips (for fast service, low hanging):
- Run this server close to your main users (region).
- Use low video resolution in your real video engine (360p / 480p).
- Use wired internet or good VPS provider.
- Later you can plug in a real WebRTC media server / TURN servers for better weak-internet calls.
