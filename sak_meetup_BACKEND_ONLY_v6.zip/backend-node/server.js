import express from 'express';
import cors from 'cors';
import axios from 'axios';

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const AI_BASE = process.env.AI_BASE || "http://backend-ai:5000";

// Health check
app.get('/', (req, res) => {
  res.json({ ok: true, service: "sak-backend-node" });
});

// TODO: plug real LiveKit token generation here
app.post('/api/livekit/token', (req, res) => {
  res.json({
    token: "LIVEKIT_TOKEN_PLACEHOLDER",
    url: process.env.LIVEKIT_WS_URL || ""
  });
});

// Proxy SK-AI calls to Python backend
app.post('/api/ai/question', async (req, res) => {
  try {
    const r = await axios.post(`${AI_BASE}/ai/question`, req.body);
    res.json(r.data);
  } catch (err) {
    console.error("AI question error", err.message);
    res.status(500).json({ error: "AI backend unavailable" });
  }
});

app.post('/api/ai/transcript', async (req, res) => {
  try {
    const r = await axios.post(`${AI_BASE}/ai/transcript`, req.body);
    res.json(r.data);
  } catch (err) {
    console.error("AI transcript error", err.message);
    res.status(500).json({ error: "AI backend unavailable" });
  }
});

app.post('/api/ai/homework', async (req, res) => {
  try {
    const r = await axios.post(`${AI_BASE}/ai/homework`, req.body);
    res.json(r.data);
  } catch (err) {
    console.error("AI homework error", err.message);
    res.status(500).json({ error: "AI backend unavailable" });
  }
});

app.post('/api/ai/support', async (req, res) => {
  try {
    const r = await axios.post(`${AI_BASE}/ai/support`, req.body);
    res.json(r.data);
  } catch (err) {
    console.error("AI support error", err.message);
    res.status(500).json({ error: "AI backend unavailable" });
  }
});


app.get('/api/ai/usage', async (req, res) => {
  try {
    const { user_id } = req.query;
    const r = await axios.get(`${AI_BASE}/ai/usage`, { params: { user_id } });
    res.json(r.data);
  } catch (err) {
    console.error("AI usage error", err.message);
    res.status(500).json({ error: "AI backend unavailable" });
  }
});

app.post('/api/ai/marketing', async (req, res) => {
  try {
    const r = await axios.post(`${AI_BASE}/ai/marketing`, req.body);
    res.json(r.data);
  } catch (err) {
    console.error("AI marketing error", err.message);
    res.status(500).json({ error: "AI backend unavailable" });
  }
});

// Recording endpoints (placeholder):
// Capture button in the classroom UI should call these endpoints.
// Only Educational plan hosts are allowed to control recording.
// A backend/video engineer must connect these to LiveKit Egress or another
// recording system on your real server.

app.post('/api/recording/start', async (req, res) => {
  try {
    const { userId, plan, roomName } = req.body || {};
    if (plan !== 'educational') {
      return res.json({
        ok: false,
        message: 'Recording is only available on the Educational plan.'
      });
    }
    // TODO: implement real recording start (e.g. LiveKit Egress) here.
    return res.json({
      ok: true,
      status: 'recording_started_placeholder',
      roomName: roomName || null
    });
  } catch (err) {
    console.error("Recording start error", err.message);
    res.status(500).json({ ok: false, error: "Recording start failed" });
  }
});

app.post('/api/recording/stop', async (req, res) => {
  try {
    const { userId, plan, roomName } = req.body || {};
    if (plan !== 'educational') {
      return res.json({
        ok: false,
        message: 'Recording is only available on the Educational plan.'
      });
    }
    // TODO: implement real recording stop and store URL/metadata in DB.
    return res.json({
      ok: true,
      status: 'recording_stopped_placeholder',
      roomName: roomName || null
    });
  } catch (err) {
    console.error("Recording stop error", err.message);
    res.status(500).json({ ok: false, error: "Recording stop failed" });
  }
});



app.listen(PORT, () => {
  console.log(`SAK Node backend running on port ${PORT}`);
});