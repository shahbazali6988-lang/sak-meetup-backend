# SAK Meetup - FINAL DEPLOY PACKAGE (with reactions)

Everything you need:

- `frontend/`       → SAK UI (landing, login, dashboards, classroom)
- `backend-node/`   → Node.js API (SK-AI proxy + LiveKit token placeholder)
- `backend-ai/`     → FastAPI AI backend skeleton
- `database/`       → PostgreSQL schema
- `docker-compose.yml` → runs Postgres + Node + AI backend

New in this build:

- InsightTap button now opens a small **reactions bar** at the bottom.
- Reactions bar has: 👍, ✋ (raise hand), ❤️, 🎉
- Clicking a reaction sends a short chat message so the host can see the reaction.

To deploy basics:

1. Install Docker and Docker Compose on a server.
2. Copy this folder to the server.
3. Run:

   docker compose up --build -d

4. Host `frontend/` on Netlify / Vercel / any static host.
5. Plug LiveKit Cloud and real AI models into the backends when you're ready.


---

## Cost control and SK-AI "team member" behavior

This package now includes:

- A basic AI usage + cost estimate layer inside `backend-ai/main.py`
- A soft limit target of **~$2 USD per user per month** for AI calls
- New endpoints:
  - `GET /api/ai/usage` → see estimated cost for a user
  - `POST /api/ai/marketing` → simple upgrade message helper

IMPORTANT:

* This is only a **skeleton**. It does NOT connect to real billing or fully
  guarantee cost under $2. To make it real, your backend developer must:

1. Connect real AI providers (OpenAI / Llama) in `backend-ai/main.py`
2. Persist per-user AI usage into the `ai_usage` table in `database/schema.sql`
3. Tune ESTIMATED_COST_PER_CALL_USD and MONTHLY_COST_LIMIT_USD to match real prices
4. Optionally, add logic to disable some AI features when the limit is reached
5. Implement real LiveKit Cloud token generation in `backend-node/server.js`
6. Apply the SAK_TIER_* thresholds from `frontend/js/classroom.js` on the media
   server side so that:
   - Small classes (<=30 users) can use 720p for everyone
   - Medium classes (31–60) use 720p host + 480p students
   - Large classes (61+) keep the host in HD and students in low-res or audio-only

With these pieces in place, you can keep total infra + AI cost per active user
close to your target while SK-AI behaves like your "team member" for support,
marketing, transcripts, and homework.


### SK-AI cost + limit logic (high level)

The AI backend now includes:

- A soft per-user AI usage estimate, targeting roughly **$2/month per active user** as an internal goal.
- A notification threshold (80% of target usage) where the frontend can warn users
  that they are nearing their monthly help usage.
- Different modes:
  - `mode = "free_light"` for free users (still get answers, lighter in real system)
  - `mode = "paid_full"` for paid users under the limit
  - `mode = "free_resources_only"` for paid users who exceeded the limit
    (should only use free / cached resources in a real implementation)
- The API **never tells users about the $ value**. Messaging is framed as
  "usage" / "limits" / "upgrade for more" instead of revealing any dollar cap.

There is also a simple retention policy description (DATA_RETENTION_DAYS = 60)
so that a real backend can delete AI logs and transcripts older than ~45–60 days
to keep storage/light and protect user privacy.

These are all **skeleton hooks** for your backend developer. They must still:

1. Connect real AI models to `simple_ai_answer()`.
2. Persist usage into the `ai_usage` table and enforce limits reliably.
3. Run periodic jobs to delete old data according to the retention policy.


### Educational plan behavior

In this version, the Educational plan is treated as **very generous / effectively unlimited**
for SK-AI usage and transcripts:

- `/ai/question` with plan `educational` returns `mode="educational_unlimited"` and does not hard-block on limits.
- `/ai/transcript` with plan `educational` also returns `mode="educational_unlimited"` and is intended to behave
  like "unlimited transcripts" from the AI side, while still trying to use free resources and efficient models first.

Student Pro / CEO plans still use the soft limit + free-resources fallback behavior described earlier.


### Free plan behavior

Free users do NOT receive SK-AI answers. When they call `/ai/question` with plan `free`,
the backend returns `ok=false` and `mode="free_blocked"` plus an `upgrade_suggestion`
string. Your frontend should show an upgrade message instead of any AI answer.

Student Pro / CEO keep soft-limit behavior with a free-resources fallback, while the
Educational plan behaves as very generous / effectively unlimited from the AI side.


### Capture button / Recording behavior

In the classroom UI, the existing **Capture** button is intended to act as the
host recording control for live sessions.

This backend now exposes placeholder endpoints:

- `POST /api/recording/start`
- `POST /api/recording/stop`

Rules:

- Only **Educational plan** hosts should be allowed to start/stop recordings.
- Other plans (free, pro, ceo) receive a JSON response with
  `ok=false` and `message="Recording is only available on the Educational plan."`

IMPORTANT:

These endpoints do NOT perform actual media recording yet. A backend/video engineer
must connect them to your real recording solution (for example, LiveKit Egress),
and store the resulting recording URLs and metadata in the database, as well as
apply your retention rules (e.g. delete old recordings after 30–60 days).
